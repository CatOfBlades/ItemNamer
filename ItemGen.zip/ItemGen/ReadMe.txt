Just double click Generate.bat to generate a new item.
You will find your fancy item description in itemsOut.txt.